'use strict';

angular.element(document).ready(function() {
  // Init the app
  angular.bootstrap(document, ['copay']);
});
